<div id="frm_adv_info" class="postbox">
	<div class="handlediv" title="<?php esc_attr_e( 'Click to toggle', 'formidable' ) ?>"><br/></div>
	<h3 class="hndle"><span><?php _e( 'Customization', 'formidable' ) ?></span></h3>
    <div class="inside">
    <?php FrmFormsController::mb_tags_box($id); ?>
    </div>
</div>
