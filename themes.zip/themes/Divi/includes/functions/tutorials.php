<a href="http://www.elegantthemes.com/members-area/tutorials/" target="_blank"><?php esc_html_e( 'Watch video tutorials', 'Divi' ); ?></a>
